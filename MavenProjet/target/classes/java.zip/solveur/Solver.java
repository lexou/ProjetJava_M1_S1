package solveur;



import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Objects;
import java.util.Stack;

import GUI.Grid;
import modele.Piece;


public class Solver {
	
	private Grid grid;
	private Stack<Piece> pile =new Stack<Piece>();
	
	
	public Solver(Grid grid) {
		this.grid=grid;
	}
	
	
	public static void main(String[] args) {
		
		// To be implemented

	}
}
