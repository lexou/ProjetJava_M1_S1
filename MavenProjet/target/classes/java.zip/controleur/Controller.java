package controleur;

import vue.FrmLoop;

public class Controller { //pas utile pour l'instant 
	FrmLoop frmLoop;
	
	//constructeur
	public Controller() {
	}
	
	
	public static void main(String[] args) {
		new Controller();
	}
	
}
